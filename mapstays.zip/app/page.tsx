import MapStays from "../components/map-stays"

export default function Page() {
  return <MapStays />
}
