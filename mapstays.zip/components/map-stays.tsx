"use client"

import { useState } from "react"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Slider } from "@/components/ui/slider"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export default function MapStays() {
  const [priceRange, setPriceRange] = useState([100])
  const [bedrooms, setBedrooms] = useState([2])
  const [bathrooms, setBathrooms] = useState([1])

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar Filters */}
      <div className="w-80 bg-white border-r border-gray-200 overflow-y-auto">
        <div className="p-6">
          <h2 className="text-xl font-semibold mb-6">Filters</h2>

          {/* Price Range */}
          <div className="mb-8">
            <h3 className="font-medium mb-4">Price range</h3>
            <Slider value={priceRange} onValueChange={setPriceRange} max={500} min={0} step={10} className="w-full" />
            <div className="flex justify-between text-sm text-gray-500 mt-2">
              <span>$0</span>
              <span>$500+</span>
            </div>
          </div>

          {/* Bedrooms */}
          <div className="mb-8">
            <h3 className="font-medium mb-4">Bedrooms</h3>
            <Slider value={bedrooms} onValueChange={setBedrooms} max={8} min={0} step={1} className="w-full" />
            <div className="flex justify-between text-sm text-gray-500 mt-2">
              <span>Any</span>
              <span>8+</span>
            </div>
          </div>

          {/* Bathrooms */}
          <div className="mb-8">
            <h3 className="font-medium mb-4">Bathrooms</h3>
            <Slider value={bathrooms} onValueChange={setBathrooms} max={8} min={0} step={1} className="w-full" />
            <div className="flex justify-between text-sm text-gray-500 mt-2">
              <span>Any</span>
              <span>8+</span>
            </div>
          </div>

          {/* Amenities */}
          <div className="mb-8">
            <h3 className="font-medium mb-4">Amenities</h3>
            <div className="space-y-3">
              {["Wifi", "Kitchen", "Parking", "Pool"].map((amenity) => (
                <div key={amenity} className="flex items-center space-x-2">
                  <Checkbox id={amenity.toLowerCase()} />
                  <label
                    htmlFor={amenity.toLowerCase()}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    {amenity}
                  </label>
                </div>
              ))}
            </div>
          </div>

          {/* Property Type */}
          <div className="mb-8">
            <h3 className="font-medium mb-4">Property Type</h3>
            <div className="space-y-3">
              {["Apartment", "House", "Cabin"].map((type) => (
                <div key={type} className="flex items-center space-x-2">
                  <Checkbox id={type.toLowerCase()} />
                  <label
                    htmlFor={type.toLowerCase()}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    {type}
                  </label>
                </div>
              ))}
            </div>
          </div>

          {/* Ratings */}
          <div className="mb-8">
            <h3 className="font-medium mb-4">Ratings</h3>
            <div className="space-y-3">
              {["4 stars & up", "3 stars & up", "2 stars & up"].map((rating) => (
                <div key={rating} className="flex items-center space-x-2">
                  <Checkbox id={rating.replace(/\s+/g, "-").toLowerCase()} />
                  <label
                    htmlFor={rating.replace(/\s+/g, "-").toLowerCase()}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    {rating}
                  </label>
                </div>
              ))}
            </div>
          </div>

          {/* Accessibility */}
          <div className="mb-8">
            <h3 className="font-medium mb-4">Accessibility</h3>
            <div className="space-y-3">
              {["Wheelchair accessible", "Elevator"].map((feature) => (
                <div key={feature} className="flex items-center space-x-2">
                  <Checkbox id={feature.replace(/\s+/g, "-").toLowerCase()} />
                  <label
                    htmlFor={feature.replace(/\s+/g, "-").toLowerCase()}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    {feature}
                  </label>
                </div>
              ))}
            </div>
          </div>

          {/* House Rules */}
          <div className="mb-8">
            <h3 className="font-medium mb-4">House Rules</h3>
            <div className="space-y-3">
              {["No smoking", "No pets"].map((rule) => (
                <div key={rule} className="flex items-center space-x-2">
                  <Checkbox id={rule.replace(/\s+/g, "-").toLowerCase()} />
                  <label
                    htmlFor={rule.replace(/\s+/g, "-").toLowerCase()}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    {rule}
                  </label>
                </div>
              ))}
            </div>
          </div>

          {/* Safety */}
          <div className="mb-8">
            <h3 className="font-medium mb-4">Safety</h3>
            <div className="space-y-3">
              {["Smoke alarm", "Carbon monoxide alarm"].map((safety) => (
                <div key={safety} className="flex items-center space-x-2">
                  <Checkbox id={safety.replace(/\s+/g, "-").toLowerCase()} />
                  <label
                    htmlFor={safety.replace(/\s+/g, "-").toLowerCase()}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    {safety}
                  </label>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-8">
              <div className="flex items-center space-x-2">
                <div className="w-6 h-6 bg-black rounded-sm flex items-center justify-center">
                  <div className="w-3 h-3 bg-white rounded-sm"></div>
                </div>
                <span className="text-xl font-semibold">MapStays</span>
              </div>
              <nav className="hidden md:flex items-center space-x-6">
                <a href="#" className="text-gray-700 hover:text-gray-900">
                  Explore
                </a>
                <a href="#" className="text-gray-700 hover:text-gray-900">
                  Wishlists
                </a>
                <a href="#" className="text-gray-700 hover:text-gray-900">
                  Trips
                </a>
                <a href="#" className="text-gray-700 hover:text-gray-900">
                  Messages
                </a>
              </nav>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input placeholder="Search" className="pl-10 w-64" />
              </div>
              <Avatar className="w-8 h-8">
                <AvatarImage src="/placeholder.svg?height=32&width=32" />
                <AvatarFallback>U</AvatarFallback>
              </Avatar>
            </div>
          </div>
        </header>

        {/* Search Bar */}
        <div className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input placeholder="Search for location" className="pl-10" />
          </div>
        </div>

        {/* Map */}
        <div className="flex-1 relative">
          <img
            src="/map-image.png"
            alt="Interactive map showing city streets and coastline"
            className="w-full h-full object-cover"
          />
        </div>
      </div>
    </div>
  )
}
