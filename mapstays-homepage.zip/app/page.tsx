import Image from "next/image"
import { Search, User, Twitter, Facebook, Instagram } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export default function MapStaysHomepage() {
  const destinations = [
    { name: "New York", image: "/placeholder.svg?height=200&width=300" },
    { name: "Los Angeles", image: "/placeholder.svg?height=200&width=300" },
    { name: "Chicago", image: "/placeholder.svg?height=200&width=300" },
    { name: "Houston", image: "/placeholder.svg?height=200&width=300" },
    { name: "Phoenix", image: "/placeholder.svg?height=200&width=300" },
    { name: "Philadelphia", image: "/placeholder.svg?height=200&width=300" },
    { name: "San Antonio", image: "/placeholder.svg?height=200&width=300" },
    { name: "San Diego", image: "/placeholder.svg?height=200&width=300" },
    { name: "Dallas", image: "/placeholder.svg?height=200&width=300" },
    { name: "San Jose", image: "/placeholder.svg?height=200&width=300" },
  ]

  const thingsToDo = [
    { title: "Great outdoors", image: "/placeholder.svg?height=150&width=200" },
    { title: "Top-rated cities", image: "/placeholder.svg?height=150&width=200" },
    { title: "Beach getaways", image: "/placeholder.svg?height=150&width=200" },
  ]

  const experiences = [
    { title: "Cooking classes", image: "/placeholder.svg?height=150&width=200" },
    { title: "Art classes", image: "/placeholder.svg?height=150&width=200" },
    { title: "Music classes", image: "/placeholder.svg?height=150&width=200" },
  ]

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="flex items-center justify-between px-6 py-4 border-b">
        <div className="flex items-center space-x-8">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-red-500 rounded flex items-center justify-center">
              <span className="text-white font-bold text-sm">+</span>
            </div>
            <span className="text-xl font-semibold text-gray-900">MapStays</span>
          </div>
          <nav className="hidden md:flex space-x-6">
            <a href="#" className="text-gray-700 hover:text-gray-900">
              Stays
            </a>
            <a href="#" className="text-gray-700 hover:text-gray-900">
              Experiences
            </a>
            <a href="#" className="text-gray-700 hover:text-gray-900">
              Online Experiences
            </a>
          </nav>
        </div>

        <div className="flex items-center space-x-4">
          <div className="relative hidden md:block">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input placeholder="Search" className="pl-10 w-64 bg-gray-100 border-0 rounded-full" />
          </div>
          <Button
            variant="outline"
            className="bg-blue-600 text-white border-blue-600 hover:bg-blue-700 rounded-full px-6"
          >
            MapStays your home
          </Button>
          <Button variant="outline" className="bg-white text-gray-700 border-gray-300 hover:bg-gray-50 rounded-full">
            Log in
          </Button>
          <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
            <User className="w-4 h-4 text-gray-600" />
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative h-96 bg-gray-900 overflow-hidden">
        <div className="absolute inset-0 bg-black bg-opacity-50"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-gray-900 via-transparent to-transparent"></div>
        <div className="relative z-10 flex flex-col justify-center h-full px-6 max-w-2xl">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Not sure where to go? Perfect.</h1>
          <p className="text-lg text-gray-200 mb-8 max-w-lg">
            Flexible destinations let you discover new places to stay, based on what matters most to you.
          </p>
          <Button className="bg-blue-600 hover:bg-blue-700 text-white rounded-full px-8 py-3 w-fit">
            I'm flexible
          </Button>
        </div>
      </section>

      {/* Discover things to do */}
      <section className="px-6 py-12">
        <h2 className="text-2xl font-semibold text-gray-900 mb-8">Discover things to do</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {thingsToDo.map((item, index) => (
            <div key={index} className="group cursor-pointer">
              <div className="relative h-48 rounded-lg overflow-hidden mb-3">
                <Image
                  src={item.image || "/placeholder.svg"}
                  alt={item.title}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <h3 className="text-lg font-medium text-gray-900">{item.title}</h3>
            </div>
          ))}
        </div>
      </section>

      {/* Discover MapStays Experiences */}
      <section className="px-6 py-12 bg-gray-50">
        <h2 className="text-2xl font-semibold text-gray-900 mb-8">Discover MapStays Experiences</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {experiences.map((item, index) => (
            <div key={index} className="group cursor-pointer">
              <div className="relative h-48 rounded-lg overflow-hidden mb-3">
                <Image
                  src={item.image || "/placeholder.svg"}
                  alt={item.title}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <h3 className="text-lg font-medium text-gray-900">{item.title}</h3>
            </div>
          ))}
        </div>
      </section>

      {/* Featured destinations */}
      <section className="px-6 py-12">
        <h2 className="text-2xl font-semibold text-gray-900 mb-8">Featured destinations</h2>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {destinations.map((destination, index) => (
            <div key={index} className="group cursor-pointer">
              <div className="relative h-32 md:h-40 rounded-lg overflow-hidden mb-2">
                <Image
                  src={destination.image || "/placeholder.svg"}
                  alt={destination.name}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <h3 className="text-sm md:text-base font-medium text-gray-900">{destination.name}</h3>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-100 px-6 py-8">
        <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <div className="flex space-x-6">
            <a href="#" className="text-gray-600 hover:text-gray-900">
              Privacy
            </a>
            <a href="#" className="text-gray-600 hover:text-gray-900">
              Terms
            </a>
            <a href="#" className="text-gray-600 hover:text-gray-900">
              Sitemap
            </a>
          </div>

          <div className="flex items-center space-x-4">
            <div className="flex space-x-3">
              <Twitter className="w-5 h-5 text-gray-600 hover:text-gray-900 cursor-pointer" />
              <Facebook className="w-5 h-5 text-gray-600 hover:text-gray-900 cursor-pointer" />
              <Instagram className="w-5 h-5 text-gray-600 hover:text-gray-900 cursor-pointer" />
            </div>
          </div>
        </div>

        <div className="text-center mt-6 pt-6 border-t border-gray-200">
          <p className="text-sm text-gray-600">© 2023 MapStays, Inc. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}
