"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Card, CardContent } from "@/components/ui/card"
import { Globe, HelpCircle, User } from "lucide-react"

export default function BookingConfirmation() {
  const [formData, setFormData] = useState({
    checkIn: "",
    checkOut: "",
    guests: "",
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    cardNumber: "",
    expiryDate: "",
    cvc: "",
    nameOnCard: "",
    agreeToTerms: false,
  })

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Booking confirmed:", formData)
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center space-x-2">
            <div className="w-6 h-6 bg-black transform rotate-45"></div>
            <span className="text-xl font-semibold text-black">MapStays</span>
          </div>

          <div className="flex items-center space-x-6">
            <button className="text-sm text-gray-700 hover:text-black">List your place</button>
            <button className="text-sm text-gray-700 hover:text-black flex items-center space-x-1">
              <HelpCircle className="w-4 h-4" />
              <span>Help</span>
            </button>
            <button className="text-sm text-gray-700 hover:text-black">
              <Globe className="w-4 h-4" />
            </button>
            <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center">
              <User className="w-4 h-4 text-white" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-2xl mx-auto px-6 py-8">
        {/* Breadcrumb */}
        <div className="text-sm text-gray-600 mb-8">San Francisco / Stay</div>

        <h1 className="text-3xl font-semibold text-gray-900 mb-8">Confirm and pay</h1>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Your trip */}
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-6">1. Your trip</h2>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <Label htmlFor="checkin" className="text-sm font-medium text-gray-700">
                    Check-in
                  </Label>
                  <Input
                    id="checkin"
                    type="date"
                    value={formData.checkIn}
                    onChange={(e) => handleInputChange("checkIn", e.target.value)}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="checkout" className="text-sm font-medium text-gray-700">
                    Checkout
                  </Label>
                  <Input
                    id="checkout"
                    type="date"
                    value={formData.checkOut}
                    onChange={(e) => handleInputChange("checkOut", e.target.value)}
                    className="mt-1"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="guests" className="text-sm font-medium text-gray-700">
                  Guests
                </Label>
                <Input
                  id="guests"
                  type="number"
                  min="1"
                  placeholder="Number of guests"
                  value={formData.guests}
                  onChange={(e) => handleInputChange("guests", e.target.value)}
                  className="mt-1"
                />
              </div>
            </CardContent>
          </Card>

          {/* Your info */}
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-6">2. Your info</h2>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="firstName" className="text-sm font-medium text-gray-700">
                    First name
                  </Label>
                  <Input
                    id="firstName"
                    type="text"
                    value={formData.firstName}
                    onChange={(e) => handleInputChange("firstName", e.target.value)}
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="lastName" className="text-sm font-medium text-gray-700">
                    Last name
                  </Label>
                  <Input
                    id="lastName"
                    type="text"
                    value={formData.lastName}
                    onChange={(e) => handleInputChange("lastName", e.target.value)}
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="email" className="text-sm font-medium text-gray-700">
                    Email address
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange("email", e.target.value)}
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="phone" className="text-sm font-medium text-gray-700">
                    Phone number
                  </Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => handleInputChange("phone", e.target.value)}
                    className="mt-1"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Payment */}
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-6">3. Payment</h2>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="cardNumber" className="text-sm font-medium text-gray-700">
                    Card number
                  </Label>
                  <Input
                    id="cardNumber"
                    type="text"
                    placeholder="Enter cardnumber"
                    value={formData.cardNumber}
                    onChange={(e) => handleInputChange("cardNumber", e.target.value)}
                    className="mt-1"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="expiryDate" className="text-sm font-medium text-gray-700">
                      Expiry date
                    </Label>
                    <Input
                      id="expiryDate"
                      type="text"
                      placeholder="MM/YY"
                      value={formData.expiryDate}
                      onChange={(e) => handleInputChange("expiryDate", e.target.value)}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="cvc" className="text-sm font-medium text-gray-700">
                      CVC
                    </Label>
                    <Input
                      id="cvc"
                      type="text"
                      placeholder="CVC"
                      value={formData.cvc}
                      onChange={(e) => handleInputChange("cvc", e.target.value)}
                      className="mt-1"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="nameOnCard" className="text-sm font-medium text-gray-700">
                    Name on card
                  </Label>
                  <Input
                    id="nameOnCard"
                    type="text"
                    placeholder="Enter nameoncard"
                    value={formData.nameOnCard}
                    onChange={(e) => handleInputChange("nameOnCard", e.target.value)}
                    className="mt-1"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Terms and Submit */}
          <div className="space-y-6">
            <div className="flex items-start space-x-2">
              <Checkbox
                id="terms"
                checked={formData.agreeToTerms}
                onCheckedChange={(checked) => handleInputChange("agreeToTerms", checked as boolean)}
              />
              <Label htmlFor="terms" className="text-sm text-gray-700 leading-5">
                I agree to the Terms of Service and Privacy Policy
              </Label>
            </div>

            <Button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 text-base font-medium"
              disabled={!formData.agreeToTerms}
            >
              Confirm and pay
            </Button>
          </div>
        </form>

        {/* Footer */}
        <div className="mt-8 text-center text-sm text-gray-500">pci-dss | ssl-secure | free-cancellation</div>
      </main>
    </div>
  )
}
