export interface Hotel {
  id: string
  name: string
  description: string
  price: number
  rating: number
  reviews: number
  location: {
    lat: number
    lng: number
    address: string
    city: string
    country: string
  }
  amenities: string[]
  images: string[]
  rooms: number
  availability: boolean
}

export interface SearchFilters {
  location: string
  checkIn: string
  checkOut: string
  guests: number
  minPrice: number
  maxPrice: number
  amenities: string[]
}
