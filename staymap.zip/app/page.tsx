"use client"

import { useState, useMemo, useEffect } from "react"
import { hotels } from "@/data/hotels"
import type { Hotel, SearchFilters } from "@/types/hotel"

export default function HomePage() {
  const [searchFilters, setSearchFilters] = useState<SearchFilters>({
    location: "",
    checkIn: "",
    checkOut: "",
    guests: 1,
    minPrice: 0,
    maxPrice: 1000,
    amenities: [],
  })

  const [selectedHotel, setSelectedHotel] = useState<Hotel | null>(null)
  const [bookingHotel, setBookingHotel] = useState<Hotel | null>(null)
  const [viewMode, setViewMode] = useState<"list" | "map">("list")

  useEffect(() => {
    // Redirect to property page for demo
    window.location.href = "/property/1"
  }, [])

  const filteredHotels = useMemo(() => {
    return hotels.filter((hotel) => {
      // Location filter
      if (
        searchFilters.location &&
        !hotel.location.city.toLowerCase().includes(searchFilters.location.toLowerCase()) &&
        !hotel.location.country.toLowerCase().includes(searchFilters.location.toLowerCase())
      ) {
        return false
      }

      // Price filter
      if (hotel.price < searchFilters.minPrice || hotel.price > searchFilters.maxPrice) {
        return false
      }

      // Amenities filter
      if (searchFilters.amenities.length > 0) {
        const hasAllAmenities = searchFilters.amenities.every((amenity) => hotel.amenities.includes(amenity))
        if (!hasAllAmenities) return false
      }

      return true
    })
  }, [searchFilters])

  const handleSearch = (filters: SearchFilters) => {
    setSearchFilters(filters)
  }

  const handleHotelSelect = (hotel: Hotel) => {
    setSelectedHotel(hotel)
  }

  const handleBooking = (hotel: Hotel) => {
    setBookingHotel(hotel)
  }

  const handleViewDetails = (hotelId: string) => {
    // In a real app, this would navigate to a detailed hotel page
    const hotel = hotels.find((h) => h.id === hotelId)
    if (hotel) {
      setSelectedHotel(hotel)
      setViewMode("map")
    }
  }

  return (
    <div className="min-h-screen bg-white flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-2xl font-semibold mb-4">Redirecting to property...</h1>
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-500 mx-auto"></div>
      </div>
    </div>
  )
}
