"use client"

import { PropertyHeader } from "@/components/property-header"
import { Breadcrumb } from "@/components/breadcrumb"
import { PropertyGallery } from "@/components/property-gallery"
import { PropertyInfo } from "@/components/property-info"
import { LocationMap } from "@/components/location-map"
import { DatePicker } from "@/components/date-picker"
import { PricingCard } from "@/components/pricing-card"

export default function PropertyPage() {
  return (
    <div className="min-h-screen bg-white">
      <PropertyHeader />

      <main className="max-w-7xl mx-auto px-6 py-8">
        <Breadcrumb />

        <div className="space-y-12">
          {/* Gallery */}
          <PropertyGallery />

          {/* Main content grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Left column - Property info */}
            <div className="lg:col-span-2 space-y-12">
              <PropertyInfo />
              <LocationMap />
              <DatePicker />
            </div>

            {/* Right column - Pricing */}
            <div className="lg:col-span-1">
              <div className="sticky top-8">
                <PricingCard />
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
