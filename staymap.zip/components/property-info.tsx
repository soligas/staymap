"use client"

export function PropertyInfo() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-semibold text-gray-900 mb-2">Cozy Cabin Retreat with Mountain Views</h1>
        <p className="text-gray-600">Cabin in Lake Tahoe, California, United States</p>
      </div>

      <div>
        <h2 className="text-xl font-semibold text-gray-900 mb-4">About this place</h2>
        <p className="text-gray-700 leading-relaxed">
          Escape to our charming cabin nestled in the heart of Lake Tahoe, offering breathtaking mountain views and a
          serene atmosphere. Perfect for a family getaway or a romantic retreat, this cozy cabin features a fully
          equipped kitchen, a spacious living area with a fireplace, and comfortable bedrooms. Enjoy outdoor activities
          like hiking, skiing, and water sports, or simply relax on the deck and soak in the natural beauty. Book your
          stay and create unforgettable memories in this idyllic mountain paradise.
        </p>
      </div>
    </div>
  )
}
