"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import type { SearchFilters } from "@/types/hotel"

interface FiltersSidebarProps {
  filters: SearchFilters
  onFiltersChange: (filters: SearchFilters) => void
}

export function FiltersSidebar({ filters, onFiltersChange }: FiltersSidebarProps) {
  const [priceRange, setPriceRange] = useState([filters.minPrice, filters.maxPrice])

  const amenitiesList = [
    "WiFi",
    "Pool",
    "Gym",
    "Spa",
    "Restaurant",
    "Room Service",
    "Beach Access",
    "Pet Friendly",
    "Business Center",
    "Parking",
  ]

  const handleAmenityChange = (amenity: string, checked: boolean) => {
    const newAmenities = checked ? [...filters.amenities, amenity] : filters.amenities.filter((a) => a !== amenity)

    onFiltersChange({ ...filters, amenities: newAmenities })
  }

  const handlePriceChange = (value: number[]) => {
    setPriceRange(value)
    onFiltersChange({
      ...filters,
      minPrice: value[0],
      maxPrice: value[1],
    })
  }

  const clearFilters = () => {
    const clearedFilters: SearchFilters = {
      ...filters,
      minPrice: 0,
      maxPrice: 1000,
      amenities: [],
    }
    setPriceRange([0, 1000])
    onFiltersChange(clearedFilters)
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Filtros</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Price Range */}
          <div>
            <Label className="text-sm font-medium">Rango de Precio</Label>
            <div className="mt-2">
              <Slider
                value={priceRange}
                onValueChange={handlePriceChange}
                max={1000}
                min={0}
                step={10}
                className="w-full"
              />
              <div className="flex justify-between text-sm text-gray-600 mt-1">
                <span>${priceRange[0]}</span>
                <span>${priceRange[1]}</span>
              </div>
            </div>
          </div>

          {/* Amenities */}
          <div>
            <Label className="text-sm font-medium">Servicios</Label>
            <div className="mt-2 space-y-2 max-h-48 overflow-y-auto">
              {amenitiesList.map((amenity) => (
                <div key={amenity} className="flex items-center space-x-2">
                  <Checkbox
                    id={amenity}
                    checked={filters.amenities.includes(amenity)}
                    onCheckedChange={(checked) => handleAmenityChange(amenity, checked as boolean)}
                  />
                  <Label htmlFor={amenity} className="text-sm">
                    {amenity}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <Button variant="outline" onClick={clearFilters} className="w-full">
            Limpiar Filtros
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
