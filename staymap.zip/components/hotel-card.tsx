"use client"

import type { Hotel } from "@/types/hotel"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { StarIcon, MapPinIcon } from "lucide-react"
import Image from "next/image"

interface HotelCardProps {
  hotel: Hotel
  onSelect: (hotel: Hotel) => void
  onViewDetails: (hotelId: string) => void
}

export function HotelCard({ hotel, onSelect, onViewDetails }: HotelCardProps) {
  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <StarIcon
        key={i}
        className={`h-4 w-4 ${i < Math.floor(rating) ? "text-yellow-400 fill-current" : "text-gray-300"}`}
      />
    ))
  }

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
      <div className="relative h-48">
        <Image src={hotel.images[0] || "/placeholder.svg"} alt={hotel.name} fill className="object-cover" />
        <div className="absolute top-2 right-2">
          <Badge variant="secondary" className="bg-white/90">
            ${hotel.price}/noche
          </Badge>
        </div>
      </div>

      <CardContent className="p-4">
        <div className="space-y-2">
          <h3 className="font-semibold text-lg">{hotel.name}</h3>

          <div className="flex items-center space-x-1">
            {renderStars(hotel.rating)}
            <span className="text-sm text-gray-600 ml-2">
              {hotel.rating} ({hotel.reviews} reseñas)
            </span>
          </div>

          <div className="flex items-center text-sm text-gray-600">
            <MapPinIcon className="h-4 w-4 mr-1" />
            {hotel.location.city}, {hotel.location.country}
          </div>

          <p className="text-sm text-gray-600 line-clamp-2">{hotel.description}</p>

          <div className="flex flex-wrap gap-1 mt-2">
            {hotel.amenities.slice(0, 3).map((amenity) => (
              <Badge key={amenity} variant="outline" className="text-xs">
                {amenity}
              </Badge>
            ))}
            {hotel.amenities.length > 3 && (
              <Badge variant="outline" className="text-xs">
                +{hotel.amenities.length - 3} más
              </Badge>
            )}
          </div>

          <div className="flex space-x-2 mt-4">
            <Button variant="outline" size="sm" onClick={() => onViewDetails(hotel.id)} className="flex-1">
              Ver Detalles
            </Button>
            <Button size="sm" onClick={() => onSelect(hotel)} className="flex-1 bg-orange-500 hover:bg-orange-600">
              Reservar
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
