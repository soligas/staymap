"use client"

import { useState } from "react"
import type { Hotel } from "@/types/hotel"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface HotelMapProps {
  hotels: Hotel[]
  selectedHotel?: Hotel
  onHotelSelect: (hotel: Hotel) => void
}

export function HotelMap({ hotels, selectedHotel, onHotelSelect }: HotelMapProps) {
  const [mapCenter, setMapCenter] = useState({ lat: 40.7589, lng: -73.9851 })

  // Simulate map functionality with a visual representation
  return (
    <Card className="h-full min-h-[500px] relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-blue-100 to-green-100">
        {/* Map background */}
        <div className="absolute inset-0 opacity-20">
          <svg className="w-full h-full" viewBox="0 0 400 300">
            {/* Simulated map roads */}
            <path d="M0,150 Q100,100 200,150 T400,150" stroke="#666" strokeWidth="2" fill="none" />
            <path d="M200,0 Q150,100 200,200 T200,300" stroke="#666" strokeWidth="2" fill="none" />
            <path d="M0,100 L400,100" stroke="#666" strokeWidth="1" fill="none" />
            <path d="M0,200 L400,200" stroke="#666" strokeWidth="1" fill="none" />
          </svg>
        </div>

        {/* Hotel markers */}
        {hotels.map((hotel, index) => (
          <div
            key={hotel.id}
            className={`absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-all ${
              selectedHotel?.id === hotel.id ? "scale-125 z-10" : "hover:scale-110"
            }`}
            style={{
              left: `${20 + ((index * 15) % 60)}%`,
              top: `${30 + ((index * 20) % 40)}%`,
            }}
            onClick={() => onHotelSelect(hotel)}
          >
            <div className={`relative ${selectedHotel?.id === hotel.id ? "animate-bounce" : ""}`}>
              <div
                className={`w-8 h-8 rounded-full border-2 border-white shadow-lg flex items-center justify-center text-white text-xs font-bold ${
                  selectedHotel?.id === hotel.id ? "bg-orange-500" : "bg-blue-500"
                }`}
              >
                ${hotel.price}
              </div>
              {selectedHotel?.id === hotel.id && (
                <div className="absolute top-10 left-1/2 transform -translate-x-1/2 w-48 z-20">
                  <Card className="p-3 shadow-lg">
                    <h4 className="font-semibold text-sm">{hotel.name}</h4>
                    <p className="text-xs text-gray-600">{hotel.location.city}</p>
                    <div className="flex justify-between items-center mt-2">
                      <Badge variant="secondary" className="text-xs">
                        ${hotel.price}/noche
                      </Badge>
                      <span className="text-xs">⭐ {hotel.rating}</span>
                    </div>
                  </Card>
                </div>
              )}
            </div>
          </div>
        ))}

        {/* Map controls */}
        <div className="absolute top-4 right-4 space-y-2">
          <button className="w-8 h-8 bg-white rounded shadow-md flex items-center justify-center hover:bg-gray-50">
            +
          </button>
          <button className="w-8 h-8 bg-white rounded shadow-md flex items-center justify-center hover:bg-gray-50">
            -
          </button>
        </div>

        {/* Map legend */}
        <div className="absolute bottom-4 left-4">
          <Card className="p-2">
            <div className="text-xs text-gray-600">
              <div className="flex items-center space-x-2 mb-1">
                <div className="w-4 h-4 bg-blue-500 rounded-full"></div>
                <span>Hoteles disponibles</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 bg-orange-500 rounded-full"></div>
                <span>Hotel seleccionado</span>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </Card>
  )
}
