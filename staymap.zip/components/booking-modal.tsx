"use client"

import type React from "react"

import { useState } from "react"
import type { Hotel } from "@/types/hotel"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { CalendarIcon, UsersIcon, CreditCardIcon } from "lucide-react"

interface BookingModalProps {
  hotel: Hotel | null
  isOpen: boolean
  onClose: () => void
}

export function BookingModal({ hotel, isOpen, onClose }: BookingModalProps) {
  const [bookingData, setBookingData] = useState({
    checkIn: "",
    checkOut: "",
    guests: 1,
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    specialRequests: "",
  })

  const [isSubmitting, setIsSubmitting] = useState(false)

  if (!hotel) return null

  const calculateNights = () => {
    if (!bookingData.checkIn || !bookingData.checkOut) return 0
    const checkIn = new Date(bookingData.checkIn)
    const checkOut = new Date(bookingData.checkOut)
    const diffTime = Math.abs(checkOut.getTime() - checkIn.getTime())
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24))
  }

  const totalPrice = calculateNights() * hotel.price

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate booking process
    await new Promise((resolve) => setTimeout(resolve, 2000))

    alert("¡Reserva confirmada! Recibirás un email de confirmación.")
    setIsSubmitting(false)
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Reservar en {hotel.name}</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Booking Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="checkIn">Check-in</Label>
                <div className="relative">
                  <CalendarIcon className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="checkIn"
                    type="date"
                    required
                    value={bookingData.checkIn}
                    onChange={(e) => setBookingData({ ...bookingData, checkIn: e.target.value })}
                    className="pl-10"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="checkOut">Check-out</Label>
                <div className="relative">
                  <CalendarIcon className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="checkOut"
                    type="date"
                    required
                    value={bookingData.checkOut}
                    onChange={(e) => setBookingData({ ...bookingData, checkOut: e.target.value })}
                    className="pl-10"
                  />
                </div>
              </div>
            </div>

            <div>
              <Label htmlFor="guests">Huéspedes</Label>
              <div className="relative">
                <UsersIcon className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="guests"
                  type="number"
                  min="1"
                  max="10"
                  required
                  value={bookingData.guests}
                  onChange={(e) => setBookingData({ ...bookingData, guests: Number.parseInt(e.target.value) })}
                  className="pl-10"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="firstName">Nombre</Label>
                <Input
                  id="firstName"
                  required
                  value={bookingData.firstName}
                  onChange={(e) => setBookingData({ ...bookingData, firstName: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="lastName">Apellido</Label>
                <Input
                  id="lastName"
                  required
                  value={bookingData.lastName}
                  onChange={(e) => setBookingData({ ...bookingData, lastName: e.target.value })}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                required
                value={bookingData.email}
                onChange={(e) => setBookingData({ ...bookingData, email: e.target.value })}
              />
            </div>

            <div>
              <Label htmlFor="phone">Teléfono</Label>
              <Input
                id="phone"
                type="tel"
                required
                value={bookingData.phone}
                onChange={(e) => setBookingData({ ...bookingData, phone: e.target.value })}
              />
            </div>

            <div>
              <Label htmlFor="specialRequests">Solicitudes Especiales</Label>
              <Textarea
                id="specialRequests"
                placeholder="Ej: Cama extra, vista al mar, etc."
                value={bookingData.specialRequests}
                onChange={(e) => setBookingData({ ...bookingData, specialRequests: e.target.value })}
              />
            </div>

            <Button type="submit" className="w-full bg-orange-500 hover:bg-orange-600" disabled={isSubmitting}>
              <CreditCardIcon className="mr-2 h-4 w-4" />
              {isSubmitting ? "Procesando..." : `Confirmar Reserva - $${totalPrice}`}
            </Button>
          </form>

          {/* Booking Summary */}
          <div>
            <Card>
              <CardContent className="p-4">
                <h3 className="font-semibold mb-4">Resumen de Reserva</h3>

                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span>Hotel:</span>
                    <span className="font-medium">{hotel.name}</span>
                  </div>

                  <div className="flex justify-between">
                    <span>Ubicación:</span>
                    <span>{hotel.location.city}</span>
                  </div>

                  <div className="flex justify-between">
                    <span>Precio por noche:</span>
                    <span>${hotel.price}</span>
                  </div>

                  <div className="flex justify-between">
                    <span>Noches:</span>
                    <span>{calculateNights()}</span>
                  </div>

                  <div className="flex justify-between">
                    <span>Huéspedes:</span>
                    <span>{bookingData.guests}</span>
                  </div>

                  <hr />

                  <div className="flex justify-between font-semibold text-lg">
                    <span>Total:</span>
                    <span>${totalPrice}</span>
                  </div>
                </div>

                <div className="mt-4 p-3 bg-gray-50 rounded">
                  <h4 className="font-medium mb-2">Servicios Incluidos:</h4>
                  <div className="flex flex-wrap gap-1">
                    {hotel.amenities.slice(0, 4).map((amenity) => (
                      <span key={amenity} className="text-xs bg-white px-2 py-1 rounded">
                        {amenity}
                      </span>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
