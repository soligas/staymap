"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { SearchIcon, MapIcon } from "lucide-react"
import Image from "next/image"

export function PropertyHeader() {
  return (
    <header className="bg-white border-b border-gray-200 px-6 py-4">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        {/* Logo and Navigation */}
        <div className="flex items-center space-x-8">
          <div className="flex items-center space-x-2">
            <MapIcon className="h-6 w-6 text-orange-500" />
            <span className="text-xl font-semibold">MapStays</span>
          </div>

          <nav className="hidden md:flex items-center space-x-6">
            <Button variant="ghost" className="text-gray-700 hover:text-gray-900">
              Explore
            </Button>
            <Button variant="ghost" className="text-gray-700 hover:text-gray-900">
              Wishlists
            </Button>
            <Button variant="ghost" className="text-gray-700 hover:text-gray-900">
              Trips
            </Button>
            <Button variant="ghost" className="text-gray-700 hover:text-gray-900">
              Messages
            </Button>
          </nav>
        </div>

        {/* Search and User */}
        <div className="flex items-center space-x-4">
          <div className="relative">
            <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input placeholder="Search" className="pl-10 w-64 bg-gray-100 border-0 rounded-full" />
          </div>

          <div className="w-8 h-8 rounded-full bg-gray-300 overflow-hidden">
            <Image
              src="/placeholder.svg?height=32&width=32"
              alt="User avatar"
              width={32}
              height={32}
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>
    </header>
  )
}
