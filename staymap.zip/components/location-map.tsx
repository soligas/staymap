"use client"

import { Card } from "@/components/ui/card"

export function LocationMap() {
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold text-gray-900">Where you'll be</h2>

      <Card className="p-6 bg-gray-50">
        <div className="relative h-64 bg-gradient-to-br from-teal-100 to-teal-300 rounded-lg overflow-hidden">
          {/* Simplified California map representation */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="relative">
              {/* California shape approximation */}
              <div className="w-32 h-48 bg-teal-400 rounded-tl-3xl rounded-bl-2xl rounded-tr-lg rounded-br-3xl relative">
                {/* Lake Tahoe marker */}
                <div className="absolute top-8 right-4 w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                <div className="absolute top-6 right-2 text-xs font-semibold text-gray-800">Lake Tahoe</div>
              </div>
            </div>
          </div>

          {/* Map legend */}
          <div className="absolute bottom-4 left-4 bg-white/90 rounded px-2 py-1 text-xs">California, USA</div>
        </div>
      </Card>
    </div>
  )
}
