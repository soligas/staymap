"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { ChevronLeftIcon, ChevronRightIcon } from "lucide-react"

const months = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
]

const daysOfWeek = ["S", "M", "T", "W", "T", "F", "S"]

export function DatePicker() {
  const [currentMonth, setCurrentMonth] = useState(6) // July (0-indexed)
  const [currentYear, setCurrentYear] = useState(2024)
  const [selectedDate, setSelectedDate] = useState<number | null>(5)

  const getDaysInMonth = (month: number, year: number) => {
    return new Date(year, month + 1, 0).getDate()
  }

  const getFirstDayOfMonth = (month: number, year: number) => {
    return new Date(year, month, 1).getDay()
  }

  const renderCalendar = (monthOffset = 0) => {
    const month = currentMonth + monthOffset
    const year = currentYear + Math.floor(month / 12)
    const adjustedMonth = month % 12

    const daysInMonth = getDaysInMonth(adjustedMonth, year)
    const firstDay = getFirstDayOfMonth(adjustedMonth, year)
    const days = []

    // Empty cells for days before the first day of the month
    for (let i = 0; i < firstDay; i++) {
      days.push(<div key={`empty-${i}`} className="h-10"></div>)
    }

    // Days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const isSelected = monthOffset === 0 && day === selectedDate
      const isToday = monthOffset === 1 && day === 7 // Example: August 7th

      days.push(
        <button
          key={day}
          onClick={() => monthOffset === 0 && setSelectedDate(day)}
          className={`h-10 w-10 rounded-full flex items-center justify-center text-sm font-medium transition-colors ${
            isSelected
              ? "bg-blue-600 text-white"
              : isToday
                ? "bg-blue-600 text-white"
                : "hover:bg-gray-100 text-gray-900"
          }`}
        >
          {day}
        </button>,
      )
    }

    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-gray-900">
            {months[adjustedMonth]} {year}
          </h3>
          {monthOffset === 0 && (
            <div className="flex space-x-1">
              <Button variant="ghost" size="sm" onClick={() => setCurrentMonth(currentMonth - 1)}>
                <ChevronLeftIcon className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" onClick={() => setCurrentMonth(currentMonth + 1)}>
                <ChevronRightIcon className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>

        <div className="grid grid-cols-7 gap-1">
          {daysOfWeek.map((day) => (
            <div key={day} className="h-10 flex items-center justify-center text-sm font-medium text-gray-500">
              {day}
            </div>
          ))}
          {days}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-gray-900">Select check-in date</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {renderCalendar(0)}
        {renderCalendar(1)}
      </div>
    </div>
  )
}
