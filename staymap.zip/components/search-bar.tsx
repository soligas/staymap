"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card } from "@/components/ui/card"
import { CalendarIcon, MapPinIcon, UsersIcon, SearchIcon } from "lucide-react"
import type { SearchFilters } from "@/types/hotel"

interface SearchBarProps {
  onSearch: (filters: SearchFilters) => void
}

export function SearchBar({ onSearch }: SearchBarProps) {
  const [filters, setFilters] = useState<SearchFilters>({
    location: "",
    checkIn: "",
    checkOut: "",
    guests: 1,
    minPrice: 0,
    maxPrice: 1000,
    amenities: [],
  })

  const handleSearch = () => {
    onSearch(filters)
  }

  return (
    <Card className="p-6 shadow-lg">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
        <div className="space-y-2">
          <Label htmlFor="location">Destino</Label>
          <div className="relative">
            <MapPinIcon className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              id="location"
              placeholder="¿A dónde vas?"
              value={filters.location}
              onChange={(e) => setFilters({ ...filters, location: e.target.value })}
              className="pl-10"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="checkin">Check-in</Label>
          <div className="relative">
            <CalendarIcon className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              id="checkin"
              type="date"
              value={filters.checkIn}
              onChange={(e) => setFilters({ ...filters, checkIn: e.target.value })}
              className="pl-10"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="checkout">Check-out</Label>
          <div className="relative">
            <CalendarIcon className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              id="checkout"
              type="date"
              value={filters.checkOut}
              onChange={(e) => setFilters({ ...filters, checkOut: e.target.value })}
              className="pl-10"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="guests">Huéspedes</Label>
          <div className="relative">
            <UsersIcon className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              id="guests"
              type="number"
              min="1"
              max="10"
              value={filters.guests}
              onChange={(e) => setFilters({ ...filters, guests: Number.parseInt(e.target.value) })}
              className="pl-10"
            />
          </div>
        </div>
      </div>

      <div className="mt-4 flex justify-center">
        <Button onClick={handleSearch} className="bg-orange-500 hover:bg-orange-600 text-white px-8">
          <SearchIcon className="mr-2 h-4 w-4" />
          Buscar Hoteles
        </Button>
      </div>
    </Card>
  )
}
