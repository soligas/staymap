"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export function PricingCard() {
  const pricing = [
    { label: "1 night", amount: 250 },
    { label: "Cleaning fee", amount: 50 },
    { label: "Service fee", amount: 30 },
    { label: "Occupancy taxes and fees", amount: 20 },
  ]

  const total = pricing.reduce((sum, item) => sum + item.amount, 0)

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-gray-900">How much does it cost?</h2>

      <Card>
        <CardContent className="p-6 space-y-4">
          {pricing.map((item, index) => (
            <div key={index} className="flex justify-between items-center">
              <span className="text-gray-700">{item.label}</span>
              <span className="font-medium">${item.amount}</span>
            </div>
          ))}

          <hr className="my-4" />

          <div className="flex justify-between items-center">
            <span className="font-semibold text-gray-900">Total before taxes</span>
            <span className="font-semibold text-gray-900">${total}</span>
          </div>
        </CardContent>
      </Card>

      <div className="text-center">
        <div className="text-2xl font-bold text-gray-900 mb-4">${total}</div>
        <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 text-lg font-semibold">Reserve</Button>
      </div>
    </div>
  )
}
