"use client"

import Image from "next/image"

const images = [
  "/placeholder.svg?height=400&width=600",
  "/placeholder.svg?height=200&width=300",
  "/placeholder.svg?height=200&width=300",
  "/placeholder.svg?height=200&width=300",
  "/placeholder.svg?height=200&width=300",
]

export function PropertyGallery() {
  return (
    <div className="grid grid-cols-4 grid-rows-2 gap-2 h-96 rounded-lg overflow-hidden">
      {/* Main large image */}
      <div className="col-span-2 row-span-2">
        <Image
          src={images[0] || "/placeholder.svg"}
          alt="Cabin exterior"
          width={600}
          height={400}
          className="w-full h-full object-cover"
        />
      </div>

      {/* Smaller images */}
      <div className="col-span-1 row-span-1">
        <Image
          src={images[1] || "/placeholder.svg"}
          alt="Interior view"
          width={300}
          height={200}
          className="w-full h-full object-cover"
        />
      </div>

      <div className="col-span-1 row-span-1">
        <Image
          src={images[2] || "/placeholder.svg"}
          alt="Living room"
          width={300}
          height={200}
          className="w-full h-full object-cover"
        />
      </div>

      <div className="col-span-1 row-span-1">
        <Image
          src={images[3] || "/placeholder.svg"}
          alt="Bedroom"
          width={300}
          height={200}
          className="w-full h-full object-cover"
        />
      </div>

      <div className="col-span-1 row-span-1">
        <Image
          src={images[4] || "/placeholder.svg"}
          alt="Kitchen"
          width={300}
          height={200}
          className="w-full h-full object-cover"
        />
      </div>
    </div>
  )
}
