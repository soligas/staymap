"use client"

import { ChevronRightIcon } from "lucide-react"

export function Breadcrumb() {
  return (
    <nav className="flex items-center space-x-2 text-sm text-gray-600 mb-6">
      <span className="hover:underline cursor-pointer">United States</span>
      <ChevronRightIcon className="h-4 w-4" />
      <span className="hover:underline cursor-pointer">California</span>
    </nav>
  )
}
